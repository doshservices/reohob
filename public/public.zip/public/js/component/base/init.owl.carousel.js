"use strict";var OwlCarouselDemo=function(){var o=function(o,e,n){o.owlCarousel({loop:!0,margin:10,nav:e,dots:n,responsive:{0:{items:1},600:{items:3},1000:{items:4}}})};return{init:function(){o($("#owl-carousel-nav"),!0,!1),o($("#owl-carousel-dots"),!1,!0)}}}();$(document).ready(function(){OwlCarouselDemo.init()});
//# sourceMappingURL=init.owl.carousel.js.map
