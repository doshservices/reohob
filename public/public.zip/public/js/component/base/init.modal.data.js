"use strict";$(function(){$("#exampleModal1").on("show.bs.modal",function(t){var a=$(t.relatedTarget).data("whatever"),e=$(this);e.find(".modal-title").text("New message to "+a),e.find(".modal-body input").val(a)})});
//# sourceMappingURL=init.modal.data.js.map
