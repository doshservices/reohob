"use strict";var DatePicker={init:function(){$(".datepicker").datepicker({todayHighlight:!0,templates:{leftArrow:'<i class="mi mi-keyboard-arrow-left"></i>',rightArrow:'<i class="mi mi-keyboard-arrow-right"></i>'}})}};$(document).ready(function(){DatePicker.init()});
//# sourceMappingURL=init.datepicker.js.map
